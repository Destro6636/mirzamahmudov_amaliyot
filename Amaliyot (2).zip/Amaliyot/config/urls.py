"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app.views import (
    CategoryAPIView, FoodsAPIView, FrontpageAPIView, MenuAPIView,
    ReservationAPIView, TableAPIView, ContactAPIView, MealTimeAPIView,
    MealAPIView, WorkshopAPIView, ShopListView, BlogListView, Blog_PostListView
)

urlpatterns = [
    path('admin/', admin.site.urls), 
    path('category/v1/', CategoryAPIView.as_view()),
    path('foods/v1/<int:pk>/', FoodsAPIView.as_view()),
    path('frontpage/v1/', FrontpageAPIView.as_view()),
    path('menu/v1/', MenuAPIView.as_view()),
    path('reservation/v1/<int:pk>/', ReservationAPIView.as_view()),
    path('table/v1/<int:pk>/', TableAPIView.as_view()),
    path('contact/v1/', ContactAPIView.as_view()),
    path('meal-time/v1/', MealTimeAPIView.as_view()),
    path('meal/v1/<int:pk>/', MealAPIView.as_view()),
    path('workshop/v1/', WorkshopAPIView.as_view()),
    path('shop/v1/', ShopListView.as_view()),
    path('blog/v1/', BlogListView.as_view()),
    path('blog_post/v1/', Blog_PostListView.as_view()),
]