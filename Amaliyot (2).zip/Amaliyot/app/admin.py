from django.contrib import admin
from .models import MealTime
from .models import Frontpage, Category, Foods, Menu, Reservation, Table, Contact, MealTime, Meal, Workshop, Blog, Blog_Post

admin.site.register([Frontpage, Category, Foods, Menu, Reservation, Table, Contact, MealTime,  Meal, Workshop, Blog, Blog_Post])

# @admin.register(MealTime)
# class MealTimeAdmin(admin.ModelAdmin):
#     list_display = ('name')