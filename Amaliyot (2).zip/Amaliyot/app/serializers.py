from rest_framework import serializers
from .models import Category, Foods, Frontpage, Menu, Reservation, Table, Contact, MealTime, Meal, Workshop,Shop, Blog, Blog_Post

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['name']
        depth = 1

class FoodsSerializer(serializers.ModelSerializer):
    category = CategorySerializer(read_only=True)

    class Meta:
        model = Foods
        fields = '__all__'

class FrontpageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Frontpage
        fields = '__all__'

class MenuSerializer(serializers.ModelSerializer):
    category = CategorySerializer(read_only=True)

    class Meta:
        model = Menu
        fields = '__all__'

class ReservationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reservation
        fields = '__all__'

class TableSerializer(serializers.ModelSerializer):
    reservation = ReservationSerializer(read_only=True)

    class Meta:
        model = Table
        fields = '__all__'

class ContactSerializer(serializers.ModelSerializer):
    class Meta:
        model = Contact
        fields = '__all__'

class MealTimeSerializer(serializers.ModelSerializer):
    class Meta:
        model = MealTime
        fields = '__all__'

class MealSerializer(serializers.ModelSerializer):
    meal_time = MealTimeSerializer(read_only=True)
    food = FoodsSerializer(read_only=True)

    class Meta:
        model = Meal
        fields = '__all__'

class WorkshopSerializer(serializers.ModelSerializer):
    class Meta:
        model = Workshop
        fields = '__all__'

class ShopSerializer(serializers.ModelSerializer):
    class Meta:
        model = Shop
        fields = '__all__'

class BlogSerializer(serializers.ModelSerializer):
    class Meta:
        model = Blog
        fields = '__all__'

class Blog_PostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Blog_Post
        fields = '__all__'